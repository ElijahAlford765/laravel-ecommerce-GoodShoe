@extends('layouts.app')

@section('content')
<h1 style="text-align:center; margin-bottom:20px;">Admin - Products</h1>

<a href="{{ route('admin.products.create') }}" 
   style="display:inline-block; margin-bottom:15px; background-color:#28a745; color:white; padding:8px 12px; border-radius:5px; text-decoration:none;">
   Add New Product
</a>

<table style="width:100%; border-collapse:collapse;">
    <thead>
        <tr style="background-color:#f8f9fa;">
            <th style="border:1px solid #ddd; padding:8px;">SKU</th>
            <th style="border:1px solid #ddd; padding:8px;">Name</th>
            <th style="border:1px solid #ddd; padding:8px;">Price</th>
            <th style="border:1px solid #ddd; padding:8px;">Stock</th>
            <th style="border:1px solid #ddd; padding:8px;">Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($products as $product)
        <tr>
            <td style="border:1px solid #ddd; padding:8px;">{{ $product->sku }}</td>
            <td style="border:1px solid #ddd; padding:8px;">{{ $product->name }}</td>
            <td style="border:1px solid #ddd; padding:8px;">${{ number_format($product->price,2) }}</td>
            <td style="border:1px solid #ddd; padding:8px;">{{ $product->stock }}</td>
            <td style="border:1px solid #ddd; padding:8px;">
                <a href="{{ route('admin.products.edit', $product->product_id) }}" 
                   style="margin-right:5px; background-color:#ffc107; color:white; padding:4px 8px; border-radius:3px; text-decoration:none;">
                   Edit
                </a>
                <form action="{{ route('admin.products.destroy', $product->product_id) }}" method="POST" style="display:inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" style="background-color:#dc3545; color:white; border:none; padding:4px 8px; border-radius:3px; cursor:pointer;">
                        Delete
                    </button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection

@extends('layouts.app')

@section('content')
<h1 style="text-align:center; margin-bottom:20px;">Add New Product</h1>

<form action="{{ route('admin.products.store') }}" method="POST">
    @csrf
    <div style="margin-bottom:10px;">
        <label>SKU:</label>
        <input type="text" name="sku" required style="width:100%; padding:6px;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Name:</label>
        <input type="text" name="name" required style="width:100%; padding:6px;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Description:</label>
        <textarea name="description" style="width:100%; padding:6px;"></textarea>
    </div>
    <div style="margin-bottom:10px;">
        <label>Price:</label>
        <input type="number" step="0.01" name="price" required style="width:100%; padding:6px;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Image URL:</label>
        <input type="text" name="image_url" style="width:100%; padding:6px;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Brand:</label>
        <input type="text" name="brand" style="width:100%; padding:6px;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Category:</label>
        <input type="text" name="category" style="width:100%; padding:6px;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Size:</label>
        <input type="text" name="size" style="width:100%; padding:6px;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Color:</label>
        <input type="text" name="color" style="width:100%; padding:6px;">
    </div>
    <div style="margin-bottom:10px;">
        <label>Stock:</label>
        <input type="number" name="stock" value="0" style="width:100%; padding:6px;">
    </div>
    <button type="submit" style="background-color:#28a745; color:white; padding:8px 12px; border-radius:5px; border:none;">Add Product</button>
</form>
@endsection

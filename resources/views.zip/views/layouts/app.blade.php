<!DOCTYPE html>
<html>
<head>
    <title>Shoe Store</title>
</head>
<body>
    <nav>
        <a href="{{ route('shop.index') }}">Home</a> | 
        <a href="{{ route('cart.index') }}">Cart</a> |
        
<a href="{{ route('admin.products.index') }}">Admin</a> |
<a href="{{ route('orders.index') }}">Orders</a>

    </nav>
    <hr>
    @yield('content')
</body>
</html>

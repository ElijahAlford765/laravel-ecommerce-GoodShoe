@extends('layouts.app')

@section('content')
<h1 style="text-align:center; margin-bottom:20px;">Our Products</h1>

<div style="display:flex; flex-wrap:wrap; justify-content:center; gap:20px;">
    @foreach($products as $product)
    <div style="border:1px solid #ddd; border-radius:10px; width:220px; padding:15px; text-align:center; box-shadow:0 2px 6px rgba(0,0,0,0.1);">
        <a href="{{ route('shop.show',$product->product_id) }}">
            <img src="{{ $product->image_url }}" alt="{{ $product->name }}" style="width:200px; height:200px; object-fit:cover; border-radius:5px;">
            <h3 style="margin:10px 0 5px 0;">{{ $product->name }}</h3>
        </a>
        <p style="font-weight:bold; color:#333;">${{ number_format($product->price,2) }}</p>
        
        <!-- Display size -->
        @if($product->size)
            <p style="color:#555;">Size: {{ $product->size }}</p>
        @endif

        <form action="{{ route('cart.add', $product->product_id) }}" method="POST">
            @csrf
            <button type="submit" style="background-color:#007bff; color:white; border:none; padding:8px 12px; border-radius:5px; cursor:pointer;">Add to Cart</button>
        </form>
    </div>
    @endforeach
</div>
@endsection

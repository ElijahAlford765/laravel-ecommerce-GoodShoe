@extends('layouts.app')
@section('content')
<h1>{{ $product->name }}</h1>
<img src="{{ $product->image_url }}" width="300">
<p>{{ $product->description }}</p>
<p>Price: ${{ $product->price }}</p>
<form action="{{ route('cart.add', $product->product_id) }}" method="POST">
    @csrf
    <button>Add to Cart</button>
</form>
@endsection

@extends('layouts.app')

@section('content')
<h1 style="text-align:center; margin-bottom:20px;">Your Cart</h1>

@if($items->count())
<table style="width:90%; margin:0 auto; border-collapse:collapse; text-align:center;">
    <thead>
        <tr style="background-color:#f2f2f2;">
            <th style="padding:10px; border:1px solid #ddd;">Product</th>
            <th style="padding:10px; border:1px solid #ddd;">Size</th>
            <th style="padding:10px; border:1px solid #ddd;">Qty</th>
            <th style="padding:10px; border:1px solid #ddd;">Price</th>
            <th style="padding:10px; border:1px solid #ddd;">Actions</th>
        </tr>
    </thead>
    <tbody>
    @foreach($items as $item)
        <tr style="border-bottom:1px solid #ddd;">
            <td style="padding:10px;">{{ $item->product->name }}</td>
            <td style="padding:10px;">{{ $item->product->size ?? 'N/A' }}</td>
            <td style="padding:10px;">
                <form action="{{ route('cart.update', $item->cart_item_id) }}" method="POST" style="display:flex; justify-content:center; gap:5px;">
                    @csrf
                    <input type="number" name="quantity" min="1" value="{{ $item->quantity }}" style="width:60px; padding:4px;">
                    <button type="submit" style="padding:4px 8px; cursor:pointer;">Update</button>
                </form>
            </td>
            <td style="padding:10px;">${{ number_format($item->price, 2) }}</td>
            <td style="padding:10px;">
                <form action="{{ route('cart.remove', $item->cart_item_id) }}" method="POST">
                    @csrf
                    <button type="submit" style="padding:4px 8px; cursor:pointer;">Remove</button>
                </form>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>

<!-- Checkout Button -->
<div style="text-align:center; margin-top:20px;">
    <a href="{{ route('checkout') }}" style="padding:10px 20px; background-color:#28a745; color:white; text-decoration:none; border-radius:5px; font-size:1.1em;">Proceed to Checkout</a>
</div>

@else
<p style="text-align:center; font-size:1.2em; margin-top:20px;">Your cart is empty.</p>
@endif
@endsection
